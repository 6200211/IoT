import asyncio
import csv
import json
import sys
import numpy as np
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from scipy.signal import find_peaks

sys.path.append('/usr/lib/python3/dist-packages')
from gps import gps, WATCH_ENABLE, WATCH_NEWSTYLE

app = FastAPI()

def load_accel_data():
    accel_z_data = []
    try:
        with open('data.csv', 'r', encoding='utf-8') as file:
            reader = csv.reader(file)
            next(reader)
            for row in reader:
                if row and len(row) >= 3:
                    accel_z_data.append(float(row[2]))
    except Exception as e:
        print(f"accelerometer error: {e}")

    z_values = np.array(accel_z_data)
    bumps_idx, _ = find_peaks(z_values, height=20000, prominence=2000, distance=30)
    potholes_idx, _ = find_peaks(z_values * -1, height=-10000, prominence=2000, distance=30)
    return len(accel_z_data), bumps_idx, potholes_idx

total_acc, bump_ind, pothole_ind = load_accel_data()

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    print('Kivy client connected to Store')

    try:
        while True:
            try:
                session = gps(host="localhost", port=3000, mode=WATCH_ENABLE | WATCH_NEWSTYLE)
                current_point_idx = 0
                total_gps_points_approx = 48

                while True:
                    report = await asyncio.to_thread(session.next)

                    if not report:
                        break

                    if 'class' in report and report['class'] == 'TPV':
                        if hasattr(report, 'lat') and hasattr(report, 'lon'):
                            lat = report.lat
                            lon = report.lon
                            defect_type = "none"

                            start_idx = int((current_point_idx / total_gps_points_approx) * total_acc)
                            end_idx = int(((current_point_idx + 1) / total_gps_points_approx) * total_acc)

                            for p_idx in pothole_ind:
                                if start_idx <= p_idx < end_idx:
                                    defect_type = "pothole"
                                    break
                            if defect_type == "none":
                                for b_idx in bump_ind:
                                    if start_idx <= b_idx < end_idx:
                                        defect_type = "bump"
                                        break

                            message = {"lat": lat, "lon": lon, "defect": defect_type}
                            await websocket.send_text(json.dumps(message))
                            print(f"Sent: {message}")
                            current_point_idx += 1

            except Exception as gps_error:
                print(f"Awaiting for GPS signal ({gps_error})")
                await asyncio.sleep(0.5)

    except WebSocketDisconnect:
        print("Kivy client disconnected from Store")
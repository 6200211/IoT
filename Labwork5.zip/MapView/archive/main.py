import csv
import numpy as np
from scipy.signal import find_peaks
from kivy.app import App
from kivy_garden.mapview import MapMarker, MapView
from kivy.clock import Clock
from kivy.logger import Logger
from lineMapLayer import LineMapLayer


class MapViewApp(App):
    def __init__(self, **kwargs):
        super().__init__()
        self.gps_route = []
        self.accel_z_data = []

        self.bumps_indices = []
        self.potholes_indices = []

        self.car_marker = None
        self.route_layer = None
        self.current_point_index = 0

    def on_start(self):
        Logger.info("App: Запуск on_start, зчитування файлів...")
        self.read_gps_data()
        self.check_road_quality()

        self.route_layer = LineMapLayer()
        self.mapview.add_layer(self.route_layer, mode="scatter")

        if self.gps_route:
            first_point = self.gps_route[0]
            self.mapview.center_on(first_point[0], first_point[1])
            self.car_marker = MapMarker(lat=first_point[0], lon=first_point[1], source='images/car.png')
            self.mapview.add_marker(self.car_marker)
            Logger.info(f"App: Маркер машини встановлено на {first_point}")
        else:
            Logger.warning("App: Маршрут порожній, маркер машини не встановлено!")

        Clock.schedule_interval(self.update, 1.5)

    def read_gps_data(self):
        try:
            with open('output.csv', 'r') as file:
                reader = csv.reader(file)
                for row in reader:
                    if row and len(row) >= 2:
                        lat, lon = float(row[0]), float(row[1])
                        self.gps_route.append((lat, lon))
            Logger.info(f"GPS: Завантажено {len(self.gps_route)} точок маршруту.")
        except Exception as e:
            Logger.error(f"GPS: Помилка зчитування файлу: {e}")

    def check_road_quality(self):
        try:
            with open('../data.csv', 'r') as file:
                reader = csv.reader(file)
                next(reader)
                for row in reader:
                    if row and len(row) >= 3:
                        self.accel_z_data.append(float(row[2]))
        except Exception as e:
            Logger.error(f"RoadQuality: Помилка зчитування акселерометра: {e}")
            return

        z_values = np.array(self.accel_z_data)

        self.bumps_indices, _ = find_peaks(z_values, height=18500, prominence=500, distance=20)

        inverted_z = z_values * -1
        self.potholes_indices, _ = find_peaks(inverted_z, height=-15000, prominence=500, distance=20)

        Logger.info(f"RoadQuality: Знайдено бордюрів/виступів: {len(self.bumps_indices)}")
        Logger.info(f"RoadQuality: Знайдено ям: {len(self.potholes_indices)}")

    def update(self, dt):
        if self.current_point_index < len(self.gps_route):
            point = self.gps_route[self.current_point_index]

            self.update_car_marker(point)
            self.route_layer.add_point(point)
            self.place_markers_for_current_segment()

            Logger.info(f"App: Рух до точки {self.current_point_index + 1}/{len(self.gps_route)}: {point}")

            self.current_point_index += 1
        else:
            Logger.info("App: Маршрут завершено!")
            return False

    def place_markers_for_current_segment(self):
        total_gps = len(self.gps_route)
        total_accel = len(self.accel_z_data)

        if total_gps == 0 or total_accel == 0:
            return

        start_idx = int((self.current_point_index / total_gps) * total_accel)
        end_idx = int(((self.current_point_index + 1) / total_gps) * total_accel)
        point = self.gps_route[self.current_point_index]

        for pothole_idx in self.potholes_indices:
            if start_idx <= pothole_idx < end_idx:
                self.set_pothole_marker(point)
                Logger.info(f"App: Встановлено маркер ЯМИ на {point}")
                break

        for bump_idx in self.bumps_indices:
            if start_idx <= bump_idx < end_idx:
                self.set_bump_marker(point)
                Logger.info(f"App: Встановлено маркер ВИСТУПУ на {point}")
                break

    def update_car_marker(self, point):
        if self.car_marker:
            self.car_marker.lat = point[0]
            self.car_marker.lon = point[1]
            self.mapview.center_on(point[0], point[1])

    def set_pothole_marker(self, point):
        marker = MapMarker(lat=point[0], lon=point[1], source='images/pothole.png')
        self.mapview.add_marker(marker)

    def set_bump_marker(self, point):
        marker = MapMarker(lat=point[0], lon=point[1], source='images/bump.png')
        self.mapview.add_marker(marker)

    def build(self):
        self.mapview = MapView(zoom=15, lat=50.45, lon=30.52)
        return self.mapview


if __name__ == "__main__":
    MapViewApp().run()
import sys

# Додаємо системну папку Ubuntu з пакетами до шляхів пошуку Conda
sys.path.append('/usr/lib/python3/dist-packages')

from gps import gps, WATCH_ENABLE, WATCH_NEWSTYLE

import csv
import numpy as np
from scipy.signal import find_peaks
import threading
from kivy.app import App
from kivy_garden.mapview import MapMarker, MapView
from kivy.clock import Clock
from kivy.logger import Logger
from lineMapLayer import LineMapLayer


class GpsListener(threading.Thread):
    # Background thread for gps listening
    def __init__(self, callback):
        super().__init__()
        self.callback = callback
        self.running = True
        self.daemon = True

    def run(self):
        try:
            Logger.info("GPS: connection to port=3000")
            session = gps(host="localhost", port=3000, mode=WATCH_ENABLE | WATCH_NEWSTYLE)
            Logger.info("GPS: Succesfully connected")

            while self.running:
                report = session.next()
                if report['class'] == 'TPV':
                    if hasattr(report, 'lat') and hasattr(report, 'lon'):
                        Clock.schedule_once(
                            lambda dt, lat=report.lat, lon=report.lon: self.callback(lat, lon),
                            0)
        except Exception as e:
            Logger.error(f"GPS: Connection error: {e}")


class MapViewApp(App):
    def __init__(self, **kwargs):
        super().__init__()
        self.car_marker = None
        self.route_layer = None

        # Accelerometer variables
        self.accel_z_data = []
        self.bumps_indices = []
        self.potholes_indices = []

        # Synchronization counters
        self.current_point_index = 0
        self.total_gps_points = 0

    def on_start(self):
        with open('output.csv', 'r', encoding='utf-8') as f:
            self.total_gps_points = sum(1 for line in f if line.strip())

        self.check_road_quality()

        self.route_layer = LineMapLayer()
        self.mapview.add_layer(self.route_layer, mode="scatter")

        self.gps_thread = GpsListener(self.update_map_from_gps)
        self.gps_thread.start()

    def check_road_quality(self):
        # Finds all bumps and potholes before the start
        try:
            with open('../data.csv', 'r', encoding='utf-8') as file:
                reader = csv.reader(file)
                next(reader)
                for row in reader:
                    if row and len(row) >= 3:
                        self.accel_z_data.append(float(row[2]))
        except Exception as e:
            Logger.error(f"RoadQuality error: {e}")
            return

        z_values = np.array(self.accel_z_data)

        # Setting filters
        self.bumps_indices, _ = find_peaks(z_values, height=20000, prominence=2000, distance=30)
        self.potholes_indices, _ = find_peaks(z_values * -1, height=-10000, prominence=2000, distance=30)

        Logger.info(f"RoadQuality: Знайдено бордюрів: {len(self.bumps_indices)}, ям: {len(self.potholes_indices)}")

    def update_map_from_gps(self, lat, lon):
        # Drawing the route and the car
        self.route_layer.add_point((lat, lon))

        if not self.car_marker:
            self.car_marker = MapMarker(lat=lat, lon=lon, source='images/car.png')
            self.mapview.add_marker(self.car_marker)
        else:
            self.car_marker.lat = lat
            self.car_marker.lon = lon

        self.mapview.center_on(lat, lon)

        total_accel = len(self.accel_z_data)
        if self.total_gps_points > 0 and total_accel > 0:
            start_idx = int((self.current_point_index / self.total_gps_points) * total_accel)
            end_idx = int(((self.current_point_index + 1) / self.total_gps_points) * total_accel)

            for p_idx in self.potholes_indices:
                if start_idx <= p_idx < end_idx:
                    self.mapview.add_marker(MapMarker(lat=lat, lon=lon, source='images/pothole.png'))
                    Logger.info(f"App: added pothole marker")
                    break

            # Перевіряємо, чи був бордюр в цю секунду
            for b_idx in self.bumps_indices:
                if start_idx <= b_idx < end_idx:
                    self.mapview.add_marker(MapMarker(lat=lat, lon=lon, source='images/bump.png'))
                    Logger.info(f"App: added bump marker")
                    break

        self.current_point_index += 1

    def build(self):
        self.mapview = MapView(zoom=15, lat=50.45, lon=30.52)
        return self.mapview


if __name__ == "__main__":
    MapViewApp().run()
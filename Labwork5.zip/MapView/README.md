### IoT Road Quality Tracker
A distributed client-server IoT application for real-time vehicle tracking and road defect (pothole/bump) detection.

### Architecture
* Backend (store-server): FastAPI application. Reads accelerometer data (data.csv), detects peaks using scipy, and broadcasts coordinates and defect events via WebSockets.

* Hardware Simulation (gps-node): Uses gpsd and gpsfake to simulate an active GPS module reading from an NMEA log (output.nmea).

* Frontend (new_main.py): Kivy & MapView desktop application. Connects to the backend via WebSockets to draw the live trajectory and place hazard markers.

### Prerequisites
* Docker and Docker Compose plugin

* Python 3.12+ (Anaconda or standard virtual environment)

* Required Python packages: kivy, kivy-garden, mapview, websocket-client

### How to Run
**1. Start the Backend (Docker)**
<br>Open a terminal in the project directory and start the server and GPS simulation:

```
sudo docker compose up --build
```
*(Wait until you see "Uvicorn running on http://0.0.0.0:8000" in the logs before proceeding)*

**2. Start the Frontend Client (Local)**
<br>Do not stop the Docker process. Open a new terminal, activate your Python environment, and run the Kivy client:
```
python new_main.py
```
**3. Stopping the System**
<br>To stop the application, simply close the Kivy map window and press ```Ctrl+C``` in the Docker terminal. To completely remove the containers, run:
```
sudo docker compose down
```

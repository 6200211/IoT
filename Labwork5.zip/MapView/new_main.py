import json
import threading
import websocket
from kivy.app import App
from kivy_garden.mapview import MapMarker, MapView
from kivy.clock import Clock
from lineMapLayer import LineMapLayer


class WebSocketListener(threading.Thread):
    """Background thread for listening to WebSocket"""
    def __init__(self, ws_url, callback):
        super().__init__()
        self.ws_url = ws_url
        self.callback = callback
        self.ws = None
        self.daemon = True

    def run(self):
        self.ws = websocket.WebSocketApp(
            self.ws_url,
            on_message=self.on_message,
            on_error=self.on_error,
            on_close=self.on_close
        )
        self.ws.run_forever()

    def on_message(self, ws, message):
        try:
            data = json.loads(message)
            Clock.schedule_once(lambda dt: self.callback(data), 0)
        except Exception as e:
            print(f"JSON parsing error: {e}")

    def on_error(self, ws, error):
        print(f"WebSocket error: {error}")

    def on_close(self, ws, close_status_code, close_msg):
        print("WebSocket connection closed")


class MapViewApp(App):
    def __init__(self, **kwargs):
        super().__init__()
        self.car_marker = None
        self.route_layer = None

    def build(self):
        self.mapview = MapView(zoom=15, lat=50.45, lon=30.52)
        return self.mapview

    def on_start(self):
        self.route_layer = LineMapLayer()
        self.mapview.add_layer(self.route_layer, mode="scatter")

        ws_url = "ws://localhost:8000/ws"
        print(f"Connection to {ws_url}")
        self.ws_thread = WebSocketListener(ws_url, self.update_map_from_server)
        self.ws_thread.start()

    def update_map_from_server(self, data):
        lat = data.get('lat')
        lon = data.get('lon')
        defect = data.get('defect', 'none')

        if lat is None or lon is None:
            return

        # Code for cycling process of building the route
        if hasattr(self, 'last_lat') and self.last_lat is not None:
            if abs(lat - self.last_lat) > 0.005 or abs(lon - self.last_lon) > 0.005:
                self.mapview.remove_layer(self.route_layer)
                self.route_layer = LineMapLayer()
                self.mapview.add_layer(self.route_layer, mode="scatter")

        self.last_lat = lat
        self.last_lon = lon

        self.mapview.center_on(lat, lon)
        self.route_layer.add_point((lat, lon))

        if not self.car_marker:
            self.car_marker = MapMarker(lat=lat, lon=lon, source='images/car.png')
            self.mapview.add_marker(self.car_marker)
        else:
            self.car_marker.lat = lat
            self.car_marker.lon = lon

        # Featuring the markers
        if defect == 'pothole':
            self.mapview.add_marker(MapMarker(lat=lat, lon=lon, source='images/pothole.png'))
            print(f"Drawing pothole at {lat:.4f}, {lon:.4f}")
        elif defect == 'bump':
            self.mapview.add_marker(MapMarker(lat=lat, lon=lon, source='images/bump.png'))
            print(f"Drawing bump at {lat:.4f}, {lon:.4f}")

if __name__ == "__main__":
    MapViewApp().run()